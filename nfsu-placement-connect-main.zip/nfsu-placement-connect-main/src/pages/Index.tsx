import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { GraduationCap, Building2, Shield, ArrowRight, Users, Briefcase, TrendingUp } from 'lucide-react';

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <div className="gradient-navy text-primary-foreground">
        <div className="container mx-auto px-4 py-6">
          <nav className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-primary-foreground/10 flex items-center justify-center">
                <GraduationCap className="h-6 w-6" />
              </div>
              <div>
                <h1 className="font-bold">NFSU Dharwad</h1>
                <p className="text-xs opacity-70">Placement Portal</p>
              </div>
            </div>
            <Link to="/auth">
              <Button variant="secondary" size="sm">
                Sign In <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </nav>
        </div>

        <div className="container mx-auto px-4 py-20 text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 leading-tight">
            Your Gateway to<br />Career Success
          </h2>
          <p className="text-lg md:text-xl opacity-80 max-w-2xl mx-auto mb-8">
            Connect with top companies, track your applications, and launch your career through NFSU Dharwad's official placement portal.
          </p>
          <Link to="/auth">
            <Button size="lg" variant="secondary" className="text-lg px-8">
              Get Started <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </div>

      {/* Stats */}
      <div className="container mx-auto px-4 -mt-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="dashboard-card text-center">
            <Users className="h-8 w-8 text-primary mx-auto mb-3" />
            <p className="text-3xl font-bold text-foreground">500+</p>
            <p className="text-muted-foreground">Students Placed</p>
          </div>
          <div className="dashboard-card text-center">
            <Building2 className="h-8 w-8 text-info mx-auto mb-3" />
            <p className="text-3xl font-bold text-foreground">50+</p>
            <p className="text-muted-foreground">Partner Companies</p>
          </div>
          <div className="dashboard-card text-center">
            <TrendingUp className="h-8 w-8 text-success mx-auto mb-3" />
            <p className="text-3xl font-bold text-foreground">12 LPA</p>
            <p className="text-muted-foreground">Highest Package</p>
          </div>
        </div>
      </div>

      {/* Features */}
      <div className="container mx-auto px-4 py-20">
        <h3 className="text-2xl font-bold text-center text-foreground mb-12">For Everyone</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="dashboard-card">
            <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
              <GraduationCap className="h-6 w-6 text-primary" />
            </div>
            <h4 className="text-lg font-semibold text-foreground mb-2">Students</h4>
            <p className="text-muted-foreground text-sm">
              Browse companies, check eligibility, apply for positions, and track your application status in real-time.
            </p>
          </div>
          <div className="dashboard-card">
            <div className="w-12 h-12 rounded-xl bg-info/10 flex items-center justify-center mb-4">
              <Building2 className="h-6 w-6 text-info" />
            </div>
            <h4 className="text-lg font-semibold text-foreground mb-2">Companies</h4>
            <p className="text-muted-foreground text-sm">
              Post job openings, define eligibility criteria, manage selection rounds, and view applicants.
            </p>
          </div>
          <div className="dashboard-card">
            <div className="w-12 h-12 rounded-xl bg-success/10 flex items-center justify-center mb-4">
              <Shield className="h-6 w-6 text-success" />
            </div>
            <h4 className="text-lg font-semibold text-foreground mb-2">Administrators</h4>
            <p className="text-muted-foreground text-sm">
              Manage students, approve profiles, oversee companies, export data, and view analytics.
            </p>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t border-border py-8">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          © 2024 National Forensic Sciences University, Dharwad Campus. All rights reserved.
        </div>
      </footer>
    </div>
  );
};

export default Index;
