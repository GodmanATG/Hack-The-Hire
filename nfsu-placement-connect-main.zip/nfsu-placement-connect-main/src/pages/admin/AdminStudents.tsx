import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  GraduationCap,
  Search,
  Filter,
  Download,
  CheckCircle2,
  XCircle,
  Ban,
  User,
  Columns,
  Loader2,
} from 'lucide-react';
import { toast } from 'sonner';

interface Student {
  id: string;
  department: string;
  batch: string;
  roll_number: string | null;
  cgpa: number | null;
  skills: string[];
  backlogs: boolean;
  phone: string | null;
  is_blacklisted: boolean;
  profile_status: string;
  profile: {
    name: string;
    email: string;
  };
}

const allColumns = [
  { key: 'name', label: 'Name' },
  { key: 'email', label: 'Email' },
  { key: 'department', label: 'Department' },
  { key: 'batch', label: 'Batch' },
  { key: 'cgpa', label: 'CGPA' },
  { key: 'phone', label: 'Phone' },
  { key: 'skills', label: 'Skills' },
  { key: 'status', label: 'Status' },
];

export default function AdminStudents() {
  const [students, setStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [departmentFilter, setDepartmentFilter] = useState<string>('all');
  const [selectedStudents, setSelectedStudents] = useState<Set<string>>(new Set());
  const [visibleColumns, setVisibleColumns] = useState<string[]>(['name', 'email', 'department', 'cgpa', 'status']);
  const [exporting, setExporting] = useState(false);

  useEffect(() => {
    fetchStudents();
  }, []);

  const fetchStudents = async () => {
    const { data } = await supabase
      .from('students')
      .select(`
        id,
        department,
        batch,
        roll_number,
        cgpa,
        skills,
        backlogs,
        phone,
        is_blacklisted,
        profile_status,
        profile:profiles(name, email)
      `)
      .order('created_at', { ascending: false });

    if (data) {
      setStudents(data as unknown as Student[]);
    }
    setLoading(false);
  };

  const updateStudentStatus = async (studentId: string, status: 'approved' | 'rejected') => {
    const { error } = await supabase
      .from('students')
      .update({ profile_status: status })
      .eq('id', studentId);

    if (error) {
      toast.error('Failed to update status');
    } else {
      toast.success(`Student ${status}`);
      fetchStudents();
    }
  };

  const toggleBlacklist = async (studentId: string, currentStatus: boolean) => {
    const { error } = await supabase
      .from('students')
      .update({ is_blacklisted: !currentStatus })
      .eq('id', studentId);

    if (error) {
      toast.error('Failed to update blacklist status');
    } else {
      toast.success(currentStatus ? 'Student removed from blacklist' : 'Student blacklisted');
      fetchStudents();
    }
  };

  const handleExportCSV = () => {
    setExporting(true);
    
    const exportData = filteredStudents.map(s => ({
      Name: s.profile?.name,
      Email: s.profile?.email,
      Department: s.department,
      Batch: s.batch,
      CGPA: s.cgpa,
      Phone: s.phone,
      Skills: s.skills?.join(', '),
      Status: s.profile_status,
      Blacklisted: s.is_blacklisted ? 'Yes' : 'No',
    }));

    const headers = Object.keys(exportData[0] || {});
    const csv = [
      headers.join(','),
      ...exportData.map(row => headers.map(h => `"${row[h as keyof typeof row] || ''}"`).join(','))
    ].join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `students_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);

    setExporting(false);
    toast.success('Exported successfully');
  };

  const departments = [...new Set(students.map(s => s.department))].filter(Boolean);

  const filteredStudents = students.filter(s => {
    const matchesSearch = 
      s.profile?.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.profile?.email?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.department?.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || s.profile_status === statusFilter;
    const matchesDept = departmentFilter === 'all' || s.department === departmentFilter;
    
    return matchesSearch && matchesStatus && matchesDept;
  });

  const toggleSelectAll = () => {
    if (selectedStudents.size === filteredStudents.length) {
      setSelectedStudents(new Set());
    } else {
      setSelectedStudents(new Set(filteredStudents.map(s => s.id)));
    }
  };

  if (loading) {
    return (
      <DashboardLayout>
        <div className="space-y-6 animate-pulse">
          <div className="h-8 w-48 bg-muted rounded" />
          <div className="h-96 bg-muted rounded-xl" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="page-header">
          <div>
            <h1 className="page-title">Student Management</h1>
            <p className="page-subtitle">Manage student profiles and approvals</p>
          </div>
          <Button onClick={handleExportCSV} disabled={exporting || filteredStudents.length === 0}>
            {exporting ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <Download className="mr-2 h-4 w-4" />
            )}
            Export CSV
          </Button>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-4">
          <div className="relative flex-1 min-w-[200px] max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search students..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-40">
              <Filter className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="approved">Approved</SelectItem>
              <SelectItem value="rejected">Rejected</SelectItem>
            </SelectContent>
          </Select>

          <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
            <SelectTrigger className="w-48">
              <GraduationCap className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Department" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Departments</SelectItem>
              {departments.map(d => (
                <SelectItem key={d} value={d}>{d}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline">
                <Columns className="h-4 w-4 mr-2" />
                Columns
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              {allColumns.map(col => (
                <DropdownMenuCheckboxItem
                  key={col.key}
                  checked={visibleColumns.includes(col.key)}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      setVisibleColumns([...visibleColumns, col.key]);
                    } else {
                      setVisibleColumns(visibleColumns.filter(c => c !== col.key));
                    }
                  }}
                >
                  {col.label}
                </DropdownMenuCheckboxItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* Table */}
        <Card className="dashboard-card overflow-hidden">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12">
                    <Checkbox
                      checked={selectedStudents.size === filteredStudents.length && filteredStudents.length > 0}
                      onCheckedChange={toggleSelectAll}
                    />
                  </TableHead>
                  {visibleColumns.includes('name') && <TableHead>Name</TableHead>}
                  {visibleColumns.includes('email') && <TableHead>Email</TableHead>}
                  {visibleColumns.includes('department') && <TableHead>Department</TableHead>}
                  {visibleColumns.includes('batch') && <TableHead>Batch</TableHead>}
                  {visibleColumns.includes('cgpa') && <TableHead>CGPA</TableHead>}
                  {visibleColumns.includes('phone') && <TableHead>Phone</TableHead>}
                  {visibleColumns.includes('skills') && <TableHead>Skills</TableHead>}
                  {visibleColumns.includes('status') && <TableHead>Status</TableHead>}
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredStudents.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={visibleColumns.length + 2} className="text-center py-8">
                      <p className="text-muted-foreground">No students found</p>
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredStudents.map((student) => (
                    <TableRow key={student.id} className={student.is_blacklisted ? 'bg-destructive/5' : ''}>
                      <TableCell>
                        <Checkbox
                          checked={selectedStudents.has(student.id)}
                          onCheckedChange={(checked) => {
                            const newSet = new Set(selectedStudents);
                            if (checked) {
                              newSet.add(student.id);
                            } else {
                              newSet.delete(student.id);
                            }
                            setSelectedStudents(newSet);
                          }}
                        />
                      </TableCell>
                      {visibleColumns.includes('name') && (
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                              <User className="h-4 w-4 text-primary" />
                            </div>
                            <span className="font-medium">{student.profile?.name}</span>
                            {student.is_blacklisted && (
                              <Badge variant="destructive" className="text-xs">Blacklisted</Badge>
                            )}
                          </div>
                        </TableCell>
                      )}
                      {visibleColumns.includes('email') && (
                        <TableCell className="text-muted-foreground">{student.profile?.email}</TableCell>
                      )}
                      {visibleColumns.includes('department') && <TableCell>{student.department}</TableCell>}
                      {visibleColumns.includes('batch') && <TableCell>{student.batch}</TableCell>}
                      {visibleColumns.includes('cgpa') && (
                        <TableCell>
                          {student.cgpa ? (
                            <span className="font-medium">{student.cgpa}</span>
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </TableCell>
                      )}
                      {visibleColumns.includes('phone') && (
                        <TableCell>{student.phone || '-'}</TableCell>
                      )}
                      {visibleColumns.includes('skills') && (
                        <TableCell>
                          <div className="flex flex-wrap gap-1 max-w-[200px]">
                            {student.skills?.slice(0, 2).map(s => (
                              <Badge key={s} variant="secondary" className="text-xs">{s}</Badge>
                            ))}
                            {student.skills?.length > 2 && (
                              <Badge variant="outline" className="text-xs">+{student.skills.length - 2}</Badge>
                            )}
                          </div>
                        </TableCell>
                      )}
                      {visibleColumns.includes('status') && (
                        <TableCell>
                          <Badge
                            className={
                              student.profile_status === 'approved'
                                ? 'status-approved'
                                : student.profile_status === 'rejected'
                                ? 'status-rejected'
                                : 'status-pending'
                            }
                          >
                            {student.profile_status}
                          </Badge>
                        </TableCell>
                      )}
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {student.profile_status === 'pending' && (
                            <>
                              <Button
                                size="sm"
                                variant="ghost"
                                className="h-8 w-8 p-0 text-success hover:text-success"
                                onClick={() => updateStudentStatus(student.id, 'approved')}
                              >
                                <CheckCircle2 className="h-4 w-4" />
                              </Button>
                              <Button
                                size="sm"
                                variant="ghost"
                                className="h-8 w-8 p-0 text-destructive hover:text-destructive"
                                onClick={() => updateStudentStatus(student.id, 'rejected')}
                              >
                                <XCircle className="h-4 w-4" />
                              </Button>
                            </>
                          )}
                          <Button
                            size="sm"
                            variant="ghost"
                            className={`h-8 w-8 p-0 ${student.is_blacklisted ? 'text-warning' : 'text-muted-foreground'}`}
                            onClick={() => toggleBlacklist(student.id, student.is_blacklisted)}
                            title={student.is_blacklisted ? 'Remove from blacklist' : 'Blacklist student'}
                          >
                            <Ban className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </Card>
      </div>
    </DashboardLayout>
  );
}
