import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Building2,
  Search,
  DollarSign,
  Calendar,
  Users,
  Eye,
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { toast } from 'sonner';
import { format } from 'date-fns';

interface Company {
  id: string;
  company_name: string;
  hr_name: string;
  hr_email: string;
  job_role: string;
  package_lpa: number;
  eligibility_criteria: any;
  application_deadline: string | null;
  rounds: any;
  status: string;
  created_at: string;
  _count?: { applications: number };
}
// Removed duplicate interface properties

export default function AdminCompanies() {
  const [companies, setCompanies] = useState<Company[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCompany, setSelectedCompany] = useState<Company | null>(null);

  useEffect(() => {
    fetchCompanies();
  }, []);

  const fetchCompanies = async () => {
    const { data } = await supabase
      .from('companies')
      .select('*')
      .order('created_at', { ascending: false });

    if (data) {
      // Fetch application counts
      const companiesWithCounts = await Promise.all(
        data.map(async (company) => {
          const { count } = await supabase
            .from('applications')
            .select('id', { count: 'exact', head: true })
            .eq('company_id', company.id);
          
          return { ...company, _count: { applications: count || 0 } };
        })
      );
      
      setCompanies(companiesWithCounts);
    }
    setLoading(false);
  };

  const toggleStatus = async (company: Company) => {
    const newStatus = company.status === 'open' ? 'closed' : 'open';
    
    const { error } = await supabase
      .from('companies')
      .update({ status: newStatus })
      .eq('id', company.id);

    if (error) {
      toast.error('Failed to update status');
    } else {
      toast.success(`Company ${newStatus === 'open' ? 'opened' : 'closed'}`);
      fetchCompanies();
    }
  };

  const filteredCompanies = companies.filter(c =>
    c.company_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.job_role.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.hr_name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) {
    return (
      <DashboardLayout>
        <div className="space-y-6 animate-pulse">
          <div className="h-8 w-48 bg-muted rounded" />
          <div className="h-96 bg-muted rounded-xl" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="page-header">
          <div>
            <h1 className="page-title">Company Management</h1>
            <p className="page-subtitle">View and manage registered companies</p>
          </div>
        </div>

        {/* Search */}
        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search companies..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>

        {/* Table */}
        <Card className="dashboard-card overflow-hidden">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Company</TableHead>
                  <TableHead>HR Contact</TableHead>
                  <TableHead>Package</TableHead>
                  <TableHead>Deadline</TableHead>
                  <TableHead>Applicants</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredCompanies.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8">
                      <p className="text-muted-foreground">No companies found</p>
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredCompanies.map((company) => (
                    <TableRow key={company.id}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                            <Building2 className="h-5 w-5 text-primary" />
                          </div>
                          <div>
                            <p className="font-medium">{company.company_name}</p>
                            <p className="text-xs text-muted-foreground">{company.job_role}</p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div>
                          <p className="font-medium">{company.hr_name}</p>
                          <p className="text-xs text-muted-foreground">{company.hr_email}</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <DollarSign className="h-4 w-4 text-muted-foreground" />
                          <span className="font-medium">{company.package_lpa} LPA</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        {company.application_deadline ? (
                          <div className="flex items-center gap-1 text-sm">
                            <Calendar className="h-4 w-4 text-muted-foreground" />
                            {format(new Date(company.application_deadline), 'MMM d, yyyy')}
                          </div>
                        ) : (
                          <span className="text-muted-foreground">-</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Users className="h-4 w-4 text-muted-foreground" />
                          <span className="font-medium">{company._count?.applications || 0}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className={company.status === 'open' ? 'status-open' : 'status-closed'}>
                          {company.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => setSelectedCompany(company)}
                          >
                            <Eye className="h-4 w-4 mr-1" />
                            View
                          </Button>
                          <Button
                            size="sm"
                            variant={company.status === 'open' ? 'outline' : 'default'}
                            onClick={() => toggleStatus(company)}
                          >
                            {company.status === 'open' ? 'Close' : 'Open'}
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </Card>

        {/* Company Details Dialog */}
        <Dialog open={!!selectedCompany} onOpenChange={() => setSelectedCompany(null)}>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>{selectedCompany?.company_name}</DialogTitle>
            </DialogHeader>
            
            {selectedCompany && (
              <div className="space-y-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Job Role</p>
                    <p className="font-medium">{selectedCompany.job_role}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Package</p>
                    <p className="font-medium">{selectedCompany.package_lpa} LPA</p>
                  </div>
                </div>

                <div>
                  <p className="text-sm text-muted-foreground mb-2">HR Contact</p>
                  <p className="font-medium">{selectedCompany.hr_name}</p>
                  <p className="text-sm text-muted-foreground">{selectedCompany.hr_email}</p>
                </div>

                {selectedCompany.eligibility_criteria && (
                  <div>
                    <p className="text-sm text-muted-foreground mb-2">Eligibility Criteria</p>
                    <div className="space-y-1 text-sm">
                      {selectedCompany.eligibility_criteria.min_cgpa && (
                        <p>Min CGPA: <strong>{selectedCompany.eligibility_criteria.min_cgpa}</strong></p>
                      )}
                      {selectedCompany.eligibility_criteria.no_backlogs && (
                        <p>No Backlogs: <strong>Required</strong></p>
                      )}
                      {selectedCompany.eligibility_criteria.departments?.length > 0 && (
                        <p>Departments: <strong>{selectedCompany.eligibility_criteria.departments.join(', ')}</strong></p>
                      )}
                      {selectedCompany.eligibility_criteria.skills?.length > 0 && (
                        <p>Skills: <strong>{selectedCompany.eligibility_criteria.skills.join(', ')}</strong></p>
                      )}
                    </div>
                  </div>
                )}

                {selectedCompany.rounds?.length > 0 && (
                  <div>
                    <p className="text-sm text-muted-foreground mb-2">Selection Rounds</p>
                    <div className="flex flex-wrap gap-2">
                      {selectedCompany.rounds.map((round, idx) => (
                        <Badge key={idx} variant="outline">
                          {idx + 1}. {round.name}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}
