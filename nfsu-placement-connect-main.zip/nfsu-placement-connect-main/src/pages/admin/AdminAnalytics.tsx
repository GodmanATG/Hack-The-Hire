import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';
import {
  TrendingUp,
  Users,
  Building2,
  CheckCircle2,
} from 'lucide-react';

interface DepartmentData {
  department: string;
  applications: number;
  selected: number;
}

interface StatusData {
  name: string;
  value: number;
  color: string;
}

export default function AdminAnalytics() {
  const [departmentData, setDepartmentData] = useState<DepartmentData[]>([]);
  const [statusData, setStatusData] = useState<StatusData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAnalytics();
  }, []);

  const fetchAnalytics = async () => {
    // Fetch applications with student data
    const { data: applications } = await supabase
      .from('applications')
      .select(`
        id,
        round_status,
        student:students(department)
      `);

    if (applications) {
      // Group by department
      const deptMap = new Map<string, { applications: number; selected: number }>();
      
      applications.forEach((app: any) => {
        const dept = app.student?.department || 'Unknown';
        const current = deptMap.get(dept) || { applications: 0, selected: 0 };
        current.applications += 1;
        if (app.round_status === 'selected') {
          current.selected += 1;
        }
        deptMap.set(dept, current);
      });

      const deptData = Array.from(deptMap.entries()).map(([dept, data]) => ({
        department: dept,
        applications: data.applications,
        selected: data.selected,
      }));
      setDepartmentData(deptData);

      // Calculate status distribution
      const statusMap = new Map<string, number>();
      applications.forEach((app: any) => {
        const status = app.round_status || 'unknown';
        statusMap.set(status, (statusMap.get(status) || 0) + 1);
      });

      const statusColors: Record<string, string> = {
        pending: '#f59e0b',
        in_progress: '#3b82f6',
        selected: '#10b981',
        rejected: '#ef4444',
      };

      const sData = Array.from(statusMap.entries()).map(([name, value]) => ({
        name: name.charAt(0).toUpperCase() + name.slice(1).replace('_', ' '),
        value,
        color: statusColors[name] || '#6b7280',
      }));
      setStatusData(sData);
    }

    setLoading(false);
  };

  if (loading) {
    return (
      <DashboardLayout>
        <div className="space-y-6 animate-pulse">
          <div className="h-8 w-48 bg-muted rounded" />
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="h-80 bg-muted rounded-xl" />
            <div className="h-80 bg-muted rounded-xl" />
          </div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="page-header">
          <div>
            <h1 className="page-title">Analytics</h1>
            <p className="page-subtitle">Placement statistics and insights</p>
          </div>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Department-wise Applications */}
          <Card className="dashboard-card">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-primary" />
                Applications by Department
              </CardTitle>
            </CardHeader>
            <CardContent>
              {departmentData.length === 0 ? (
                <div className="h-64 flex items-center justify-center text-muted-foreground">
                  No data available
                </div>
              ) : (
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={departmentData} layout="vertical" margin={{ left: 20 }}>
                    <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} />
                    <XAxis type="number" />
                    <YAxis 
                      type="category" 
                      dataKey="department" 
                      width={120}
                      tick={{ fontSize: 12 }}
                    />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px',
                      }}
                    />
                    <Bar dataKey="applications" fill="hsl(var(--primary))" name="Applications" radius={[0, 4, 4, 0]} />
                    <Bar dataKey="selected" fill="hsl(var(--success))" name="Selected" radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>

          {/* Application Status Distribution */}
          <Card className="dashboard-card">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <CheckCircle2 className="h-5 w-5 text-success" />
                Application Status
              </CardTitle>
            </CardHeader>
            <CardContent>
              {statusData.length === 0 ? (
                <div className="h-64 flex items-center justify-center text-muted-foreground">
                  No data available
                </div>
              ) : (
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={statusData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {statusData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px',
                      }}
                    />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Selection Funnel */}
        <Card className="dashboard-card">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Users className="h-5 w-5 text-info" />
              Selection Funnel
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between py-8">
              {statusData.map((status, idx) => (
                <div key={status.name} className="flex-1 text-center">
                  <div 
                    className="w-20 h-20 mx-auto rounded-full flex items-center justify-center text-xl font-bold"
                    style={{ 
                      backgroundColor: `${status.color}20`,
                      color: status.color,
                    }}
                  >
                    {status.value}
                  </div>
                  <p className="mt-2 text-sm font-medium text-foreground">{status.name}</p>
                  {idx < statusData.length - 1 && (
                    <div className="absolute top-1/2 right-0 w-8 h-0.5 bg-border" />
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
