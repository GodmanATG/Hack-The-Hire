import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  GraduationCap,
  Building2,
  FileText,
  CheckCircle2,
  Clock,
  XCircle,
  Users,
  TrendingUp,
} from 'lucide-react';

interface Stats {
  totalStudents: number;
  approvedStudents: number;
  pendingStudents: number;
  totalCompanies: number;
  openCompanies: number;
  totalApplications: number;
  selectedApplications: number;
  pendingApplications: number;
}

export default function AdminDashboard() {
  const [stats, setStats] = useState<Stats>({
    totalStudents: 0,
    approvedStudents: 0,
    pendingStudents: 0,
    totalCompanies: 0,
    openCompanies: 0,
    totalApplications: 0,
    selectedApplications: 0,
    pendingApplications: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      // Fetch students
      const { data: students } = await supabase.from('students').select('id, profile_status');
      
      // Fetch companies
      const { data: companies } = await supabase.from('companies').select('id, status');
      
      // Fetch applications
      const { data: applications } = await supabase.from('applications').select('id, round_status');

      if (students && companies && applications) {
        setStats({
          totalStudents: students.length,
          approvedStudents: students.filter(s => s.profile_status === 'approved').length,
          pendingStudents: students.filter(s => s.profile_status === 'pending').length,
          totalCompanies: companies.length,
          openCompanies: companies.filter(c => c.status === 'open').length,
          totalApplications: applications.length,
          selectedApplications: applications.filter(a => a.round_status === 'selected').length,
          pendingApplications: applications.filter(a => a.round_status === 'pending' || a.round_status === 'in_progress').length,
        });
      }

      setLoading(false);
    };

    fetchStats();
  }, []);

  const statCards = [
    {
      title: 'Total Students',
      value: stats.totalStudents,
      icon: <GraduationCap className="h-5 w-5" />,
      color: 'text-primary',
      bgColor: 'bg-primary/10',
      subtitle: `${stats.approvedStudents} approved`,
    },
    {
      title: 'Pending Approvals',
      value: stats.pendingStudents,
      icon: <Clock className="h-5 w-5" />,
      color: 'text-warning',
      bgColor: 'bg-warning/10',
      subtitle: 'Student profiles',
    },
    {
      title: 'Companies',
      value: stats.totalCompanies,
      icon: <Building2 className="h-5 w-5" />,
      color: 'text-info',
      bgColor: 'bg-info/10',
      subtitle: `${stats.openCompanies} active`,
    },
    {
      title: 'Applications',
      value: stats.totalApplications,
      icon: <FileText className="h-5 w-5" />,
      color: 'text-primary',
      bgColor: 'bg-primary/10',
      subtitle: `${stats.pendingApplications} in progress`,
    },
    {
      title: 'Selections',
      value: stats.selectedApplications,
      icon: <CheckCircle2 className="h-5 w-5" />,
      color: 'text-success',
      bgColor: 'bg-success/10',
      subtitle: 'Students placed',
    },
    {
      title: 'Placement Rate',
      value: stats.totalStudents > 0 
        ? `${Math.round((stats.selectedApplications / stats.totalStudents) * 100)}%` 
        : '0%',
      icon: <TrendingUp className="h-5 w-5" />,
      color: 'text-success',
      bgColor: 'bg-success/10',
      subtitle: 'Overall success',
    },
  ];

  if (loading) {
    return (
      <DashboardLayout>
        <div className="space-y-6 animate-pulse">
          <div className="h-8 w-48 bg-muted rounded" />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="h-32 bg-muted rounded-xl" />
            ))}
          </div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold text-foreground">Admin Dashboard</h1>
          <p className="text-muted-foreground">
            Overview of placement activities
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {statCards.map((stat) => (
            <Card key={stat.title} className="dashboard-card">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">{stat.title}</p>
                    <p className="text-3xl font-bold text-foreground mt-1">{stat.value}</p>
                    <p className="text-xs text-muted-foreground mt-1">{stat.subtitle}</p>
                  </div>
                  <div className={`p-4 rounded-xl ${stat.bgColor}`}>
                    <div className={stat.color}>{stat.icon}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="dashboard-card">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Clock className="h-5 w-5 text-warning" />
                Recent Activity
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                  <GraduationCap className="h-4 w-4 text-primary" />
                  <p className="text-sm">{stats.pendingStudents} students awaiting profile approval</p>
                </div>
                <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                  <Building2 className="h-4 w-4 text-info" />
                  <p className="text-sm">{stats.openCompanies} companies actively hiring</p>
                </div>
                <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                  <FileText className="h-4 w-4 text-warning" />
                  <p className="text-sm">{stats.pendingApplications} applications in progress</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="dashboard-card">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-success" />
                Placement Summary
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Total Applications</span>
                  <span className="font-semibold">{stats.totalApplications}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Successful Placements</span>
                  <span className="font-semibold text-success">{stats.selectedApplications}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Active Students</span>
                  <span className="font-semibold">{stats.approvedStudents}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Partner Companies</span>
                  <span className="font-semibold">{stats.totalCompanies}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
