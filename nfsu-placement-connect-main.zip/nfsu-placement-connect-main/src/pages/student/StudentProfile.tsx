import { useEffect, useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  User,
  Save,
  Loader2,
  CheckCircle2,
  Clock,
  XCircle,
  Upload,
  Plus,
  X,
  AlertTriangle,
} from 'lucide-react';
import { toast } from 'sonner';

interface StudentData {
  id: string;
  department: string;
  batch: string;
  roll_number: string | null;
  cgpa: number | null;
  skills: string[];
  backlogs: boolean;
  resume_url: string | null;
  phone: string | null;
  linkedin_url: string | null;
  profile_status: string;
  profile_completion: number;
}

const DEPARTMENTS = [
  'Computer Science',
  'Cyber Security',
  'Forensic Science',
  'Digital Forensics',
  'Data Science',
  'Information Technology',
  'Other',
];

const BATCHES = ['2021', '2022', '2023', '2024', '2025'];

export default function StudentProfile() {
  const { profile, refreshProfile } = useAuth();
  const [student, setStudent] = useState<StudentData | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [isNewStudent, setIsNewStudent] = useState(false);

  // Form state
  const [department, setDepartment] = useState('');
  const [batch, setBatch] = useState('');
  const [rollNumber, setRollNumber] = useState('');
  const [cgpa, setCgpa] = useState('');
  const [phone, setPhone] = useState('');
  const [linkedinUrl, setLinkedinUrl] = useState('');
  const [skills, setSkills] = useState<string[]>([]);
  const [newSkill, setNewSkill] = useState('');
  const [backlogs, setBacklogs] = useState(false);

  useEffect(() => {
    const fetchStudent = async () => {
      if (!profile?.id) return;

      const { data, error } = await supabase
        .from('students')
        .select('*')
        .eq('profile_id', profile.id)
        .single();

      if (error && error.code === 'PGRST116') {
        // No student record exists
        setIsNewStudent(true);
      } else if (data) {
        setStudent(data as StudentData);
        setDepartment(data.department);
        setBatch(data.batch);
        setRollNumber(data.roll_number || '');
        setCgpa(data.cgpa?.toString() || '');
        setPhone(data.phone || '');
        setLinkedinUrl(data.linkedin_url || '');
        setSkills(data.skills || []);
        setBacklogs(data.backlogs || false);
      }

      setLoading(false);
    };

    fetchStudent();
  }, [profile?.id]);

  const calculateCompletion = () => {
    let score = 0;
    if (department) score += 20;
    if (batch) score += 10;
    if (cgpa) score += 20;
    if (skills.length > 0) score += 20;
    if (phone) score += 10;
    if (rollNumber) score += 10;
    if (linkedinUrl) score += 10;
    return score;
  };

  const handleAddSkill = () => {
    if (newSkill.trim() && !skills.includes(newSkill.trim())) {
      setSkills([...skills, newSkill.trim()]);
      setNewSkill('');
    }
  };

  const handleRemoveSkill = (skill: string) => {
    setSkills(skills.filter(s => s !== skill));
  };

  const handleSave = async () => {
    if (!profile?.id) return;

    if (!department || !batch) {
      toast.error('Please fill in required fields');
      return;
    }

    setSaving(true);

    const studentData = {
      profile_id: profile.id,
      department,
      batch,
      roll_number: rollNumber || null,
      cgpa: cgpa ? parseFloat(cgpa) : null,
      phone: phone || null,
      linkedin_url: linkedinUrl || null,
      skills,
      backlogs,
      profile_completion: calculateCompletion(),
      profile_status: 'pending' as const,
    };

    let error;

    if (isNewStudent) {
      const result = await supabase.from('students').insert(studentData).select().single();
      error = result.error;
      if (result.data) {
        setStudent(result.data as StudentData);
        setIsNewStudent(false);
      }
    } else if (student) {
      const result = await supabase
        .from('students')
        .update(studentData)
        .eq('id', student.id)
        .select()
        .single();
      error = result.error;
      if (result.data) {
        setStudent(result.data as StudentData);
      }
    }

    if (error) {
      toast.error('Failed to save profile', { description: error.message });
    } else {
      toast.success('Profile saved!', {
        description: 'Your profile is now pending admin approval.',
      });
    }

    setSaving(false);
  };

  const statusConfig: Record<string, { label: string; className: string; icon: React.ReactNode }> = {
    pending: { label: 'Pending Approval', className: 'status-pending', icon: <Clock className="h-3 w-3" /> },
    approved: { label: 'Approved', className: 'status-approved', icon: <CheckCircle2 className="h-3 w-3" /> },
    rejected: { label: 'Rejected', className: 'status-rejected', icon: <XCircle className="h-3 w-3" /> },
  };

  if (loading) {
    return (
      <DashboardLayout>
        <div className="space-y-6 animate-pulse">
          <div className="h-8 w-48 bg-muted rounded" />
          <div className="h-96 bg-muted rounded-xl" />
        </div>
      </DashboardLayout>
    );
  }

  const status = statusConfig[student?.profile_status || 'pending'];

  return (
    <DashboardLayout>
      <div className="space-y-6 max-w-3xl">
        {/* Header */}
        <div className="page-header">
          <div>
            <h1 className="page-title">Student Profile</h1>
            <p className="page-subtitle">Manage your profile information</p>
          </div>
          {student && (
            <Badge className={status.className}>
              {status.icon}
              <span className="ml-1">{status.label}</span>
            </Badge>
          )}
        </div>

        {/* Alert for pending/rejected */}
        {student?.profile_status === 'pending' && (
          <Card className="border-warning bg-warning/5">
            <CardContent className="flex items-center gap-4 p-4">
              <Clock className="h-5 w-5 text-warning flex-shrink-0" />
              <div>
                <p className="font-medium text-foreground">Profile Under Review</p>
                <p className="text-sm text-muted-foreground">
                  Your profile changes are pending admin approval
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Profile Form */}
        <Card className="dashboard-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5" />
              Personal Information
            </CardTitle>
            <CardDescription>
              Your basic details for placement eligibility
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Basic Info */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Full Name</Label>
                <Input value={profile?.name || ''} disabled className="bg-muted" />
              </div>
              <div className="space-y-2">
                <Label>Email</Label>
                <Input value={profile?.email || ''} disabled className="bg-muted" />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="department">Department *</Label>
                <Select value={department} onValueChange={setDepartment}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select department" />
                  </SelectTrigger>
                  <SelectContent>
                    {DEPARTMENTS.map(d => (
                      <SelectItem key={d} value={d}>{d}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="batch">Batch *</Label>
                <Select value={batch} onValueChange={setBatch}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select batch" />
                  </SelectTrigger>
                  <SelectContent>
                    {BATCHES.map(b => (
                      <SelectItem key={b} value={b}>{b}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="rollNumber">Roll Number</Label>
                <Input
                  id="rollNumber"
                  value={rollNumber}
                  onChange={(e) => setRollNumber(e.target.value)}
                  placeholder="e.g., 21CS101"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="cgpa">CGPA (0-10)</Label>
                <Input
                  id="cgpa"
                  type="number"
                  step="0.01"
                  min="0"
                  max="10"
                  value={cgpa}
                  onChange={(e) => setCgpa(e.target.value)}
                  placeholder="e.g., 8.5"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+91 9876543210"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="linkedin">LinkedIn URL</Label>
                <Input
                  id="linkedin"
                  value={linkedinUrl}
                  onChange={(e) => setLinkedinUrl(e.target.value)}
                  placeholder="https://linkedin.com/in/..."
                />
              </div>
            </div>

            {/* Backlogs */}
            <div className="flex items-center justify-between p-4 rounded-lg bg-muted">
              <div>
                <Label htmlFor="backlogs">Active Backlogs</Label>
                <p className="text-sm text-muted-foreground">
                  Do you have any active backlogs?
                </p>
              </div>
              <Switch
                id="backlogs"
                checked={backlogs}
                onCheckedChange={setBacklogs}
              />
            </div>

            {/* Skills */}
            <div className="space-y-3">
              <Label>Skills</Label>
              <div className="flex gap-2">
                <Input
                  value={newSkill}
                  onChange={(e) => setNewSkill(e.target.value)}
                  placeholder="Add a skill (e.g., Python)"
                  onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddSkill())}
                />
                <Button type="button" variant="outline" onClick={handleAddSkill}>
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              <div className="flex flex-wrap gap-2">
                {skills.map((skill) => (
                  <Badge key={skill} variant="secondary" className="pl-3 pr-2 py-1">
                    {skill}
                    <button
                      onClick={() => handleRemoveSkill(skill)}
                      className="ml-2 hover:text-destructive"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </Badge>
                ))}
                {skills.length === 0 && (
                  <p className="text-sm text-muted-foreground">No skills added yet</p>
                )}
              </div>
            </div>

            {/* Resume Upload Notice */}
            <div className="flex items-start gap-3 p-4 rounded-lg bg-muted">
              <Upload className="h-5 w-5 text-muted-foreground mt-0.5" />
              <div>
                <p className="text-sm font-medium text-foreground">Resume Upload</p>
                <p className="text-sm text-muted-foreground">
                  Resume upload feature coming soon. For now, you can add your LinkedIn profile.
                </p>
              </div>
            </div>

            {/* Save Button */}
            <div className="flex justify-end pt-4 border-t border-border">
              <Button onClick={handleSave} disabled={saving}>
                {saving ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Saving...
                  </>
                ) : (
                  <>
                    <Save className="mr-2 h-4 w-4" />
                    Save Profile
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
