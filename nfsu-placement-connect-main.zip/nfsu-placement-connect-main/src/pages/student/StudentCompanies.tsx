import { useEffect, useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Building2,
  Search,
  Calendar,
  DollarSign,
  Users,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Loader2,
  Info,
} from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

interface EligibilityCriteria {
  min_cgpa?: number;
  departments?: string[];
  skills?: string[];
  no_backlogs?: boolean;
}

interface Company {
  id: string;
  company_name: string;
  job_role: string;
  job_description: string | null;
  package_lpa: number;
  application_deadline: string | null;
  eligibility_criteria: EligibilityCriteria;
  rounds: any[];
  status: string;
}

interface StudentData {
  id: string;
  department: string;
  cgpa: number | null;
  skills: string[];
  backlogs: boolean;
  profile_status: string;
  resume_url: string | null;
}

interface EligibilityResult {
  eligible: boolean;
  reasons: string[];
}

export default function StudentCompanies() {
  const { profile } = useAuth();
  const [companies, setCompanies] = useState<Company[]>([]);
  const [student, setStudent] = useState<StudentData | null>(null);
  const [appliedCompanies, setAppliedCompanies] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCompany, setSelectedCompany] = useState<Company | null>(null);
  const [applyDialogOpen, setApplyDialogOpen] = useState(false);
  const [applying, setApplying] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      if (!profile?.id) return;

      // Fetch student data
      const { data: studentData } = await supabase
        .from('students')
        .select('*')
        .eq('profile_id', profile.id)
        .single();

      if (studentData) {
        setStudent(studentData as StudentData);

        // Fetch applied companies
        const { data: appsData } = await supabase
          .from('applications')
          .select('company_id')
          .eq('student_id', studentData.id);

        if (appsData) {
          setAppliedCompanies(new Set(appsData.map(a => a.company_id)));
        }
      }

      // Fetch companies
      const { data: companiesData } = await supabase
        .from('companies')
        .select('*')
        .eq('status', 'open')
        .order('created_at', { ascending: false });

      if (companiesData) {
        setCompanies(companiesData as Company[]);
      }

      setLoading(false);
    };

    fetchData();
  }, [profile?.id]);

  const checkEligibility = (company: Company): EligibilityResult => {
    if (!student) {
      return { eligible: false, reasons: ['Complete your student profile first'] };
    }

    const reasons: string[] = [];
    const criteria = company.eligibility_criteria || {};

    // Check CGPA
    if (criteria.min_cgpa && (!student.cgpa || student.cgpa < criteria.min_cgpa)) {
      reasons.push(`Minimum CGPA required: ${criteria.min_cgpa} (Your CGPA: ${student.cgpa || 'Not set'})`);
    }

    // Check department
    if (criteria.departments?.length > 0 && !criteria.departments.includes(student.department)) {
      reasons.push(`Eligible departments: ${criteria.departments.join(', ')}`);
    }

    // Check backlogs
    if (criteria.no_backlogs && student.backlogs) {
      reasons.push('No active backlogs allowed');
    }

    // Check skills
    if (criteria.skills?.length > 0) {
      const matchingSkills = criteria.skills.filter(s => 
        student.skills?.some(ss => ss.toLowerCase().includes(s.toLowerCase()))
      );
      if (matchingSkills.length === 0) {
        reasons.push(`Required skills: ${criteria.skills.join(', ')}`);
      }
    }

    // Check profile status
    if (student.profile_status !== 'approved') {
      reasons.push('Your profile must be approved to apply');
    }

    // Check resume
    if (!student.resume_url) {
      reasons.push('Resume is required to apply');
    }

    return {
      eligible: reasons.length === 0,
      reasons,
    };
  };

  const handleApply = async () => {
    if (!selectedCompany || !student) return;

    setApplying(true);

    const { error } = await supabase.from('applications').insert({
      student_id: student.id,
      company_id: selectedCompany.id,
      current_round: 1,
      round_status: 'pending',
      timeline: [{
        round: 1,
        status: 'applied',
        timestamp: new Date().toISOString(),
      }],
    });

    if (error) {
      toast.error('Failed to apply', { description: error.message });
    } else {
      toast.success('Application submitted!', {
        description: `You've applied to ${selectedCompany.company_name}`,
      });
      setAppliedCompanies(prev => new Set([...prev, selectedCompany.id]));
    }

    setApplying(false);
    setApplyDialogOpen(false);
    setSelectedCompany(null);
  };

  const filteredCompanies = companies.filter(c =>
    c.company_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.job_role.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) {
    return (
      <DashboardLayout>
        <div className="space-y-6 animate-pulse">
          <div className="h-8 w-48 bg-muted rounded" />
          <div className="h-10 w-full max-w-md bg-muted rounded" />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="h-48 bg-muted rounded-xl" />
            ))}
          </div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="page-header">
          <div>
            <h1 className="page-title">Available Companies</h1>
            <p className="page-subtitle">Browse and apply to open positions</p>
          </div>
        </div>

        {/* Search */}
        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search companies or roles..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>

        {/* Companies Grid */}
        {filteredCompanies.length === 0 ? (
          <div className="empty-state py-16">
            <Building2 className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-lg font-medium text-foreground">No companies found</p>
            <p className="text-muted-foreground">Check back later for new opportunities</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredCompanies.map((company) => {
              const eligibility = checkEligibility(company);
              const hasApplied = appliedCompanies.has(company.id);

              return (
                <Card key={company.id} className="dashboard-card group">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-lg">{company.company_name}</CardTitle>
                        <p className="text-sm text-muted-foreground mt-1">{company.job_role}</p>
                      </div>
                      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                        <Building2 className="h-5 w-5 text-primary" />
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center gap-4 text-sm">
                      <div className="flex items-center gap-1.5 text-muted-foreground">
                        <DollarSign className="h-4 w-4" />
                        <span className="font-medium text-foreground">{company.package_lpa} LPA</span>
                      </div>
                      {company.application_deadline && (
                        <div className="flex items-center gap-1.5 text-muted-foreground">
                          <Calendar className="h-4 w-4" />
                          <span>{format(new Date(company.application_deadline), 'MMM d')}</span>
                        </div>
                      )}
                    </div>

                    {/* Eligibility Status */}
                    <div className="flex items-center gap-2">
                      {eligibility.eligible ? (
                        <Badge className="status-approved">
                          <CheckCircle2 className="h-3 w-3 mr-1" />
                          Eligible
                        </Badge>
                      ) : (
                        <Badge className="status-rejected">
                          <XCircle className="h-3 w-3 mr-1" />
                          Not Eligible
                        </Badge>
                      )}
                      {!eligibility.eligible && (
                        <button
                          className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1"
                          onClick={() => {
                            setSelectedCompany(company);
                          }}
                        >
                          <Info className="h-3 w-3" />
                          Why?
                        </button>
                      )}
                    </div>

                    {/* Actions */}
                    {hasApplied ? (
                      <Button variant="secondary" className="w-full" disabled>
                        <CheckCircle2 className="mr-2 h-4 w-4" />
                        Applied
                      </Button>
                    ) : (
                      <Button
                        className="w-full"
                        disabled={!eligibility.eligible}
                        onClick={() => {
                          setSelectedCompany(company);
                          setApplyDialogOpen(true);
                        }}
                      >
                        Apply Now
                      </Button>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}

        {/* Apply Dialog */}
        <Dialog open={applyDialogOpen} onOpenChange={setApplyDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Apply to {selectedCompany?.company_name}</DialogTitle>
              <DialogDescription>
                You're about to apply for the {selectedCompany?.job_role} position.
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4 py-4">
              <div className="flex items-center gap-3 p-3 rounded-lg bg-muted">
                <DollarSign className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="text-sm font-medium">Package</p>
                  <p className="text-lg font-bold text-foreground">{selectedCompany?.package_lpa} LPA</p>
                </div>
              </div>

              {selectedCompany?.rounds && selectedCompany.rounds.length > 0 && (
                <div className="p-3 rounded-lg bg-muted">
                  <p className="text-sm font-medium mb-2">Selection Process</p>
                  <div className="flex flex-wrap gap-2">
                    {selectedCompany.rounds.map((round: any, idx: number) => (
                      <Badge key={idx} variant="outline">
                        {idx + 1}. {round.name || round}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex items-center gap-2 p-3 rounded-lg bg-warning/10 text-warning">
                <AlertTriangle className="h-4 w-4 flex-shrink-0" />
                <p className="text-sm">
                  Make sure your profile and resume are up to date before applying.
                </p>
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setApplyDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleApply} disabled={applying}>
                {applying ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Submitting...
                  </>
                ) : (
                  'Confirm Application'
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Ineligibility Reasons Dialog */}
        <Dialog open={!!selectedCompany && !applyDialogOpen} onOpenChange={() => setSelectedCompany(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Eligibility Requirements</DialogTitle>
              <DialogDescription>
                Here's why you're not eligible for {selectedCompany?.company_name}
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-3 py-4">
              {selectedCompany && checkEligibility(selectedCompany).reasons.map((reason, idx) => (
                <div key={idx} className="flex items-start gap-3 p-3 rounded-lg bg-destructive/5">
                  <XCircle className="h-5 w-5 text-destructive flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-foreground">{reason}</p>
                </div>
              ))}
            </div>

            <DialogFooter>
              <Button onClick={() => setSelectedCompany(null)}>
                Understood
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}
