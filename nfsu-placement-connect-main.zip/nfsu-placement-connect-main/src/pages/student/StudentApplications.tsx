import { useEffect, useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  FileText,
  Building2,
  Clock,
  CheckCircle2,
  XCircle,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

interface TimelineEntry {
  round: number;
  status: string;
  timestamp: string;
  notes?: string;
}

interface Application {
  id: string;
  current_round: number;
  round_status: string;
  timeline: TimelineEntry[];
  created_at: string;
  company: {
    company_name: string;
    job_role: string;
    package_lpa: number;
    rounds: any[];
  };
}

const statusConfig: Record<string, { label: string; className: string; icon: React.ReactNode }> = {
  pending: { label: 'Pending', className: 'status-pending', icon: <Clock className="h-3 w-3" /> },
  in_progress: { label: 'In Progress', className: 'status-pending', icon: <Clock className="h-3 w-3" /> },
  selected: { label: 'Selected', className: 'status-approved', icon: <CheckCircle2 className="h-3 w-3" /> },
  rejected: { label: 'Rejected', className: 'status-rejected', icon: <XCircle className="h-3 w-3" /> },
  applied: { label: 'Applied', className: 'status-pending', icon: <Clock className="h-3 w-3" /> },
};

export default function StudentApplications() {
  const { profile } = useAuth();
  const [applications, setApplications] = useState<Application[]>([]);
  const [loading, setLoading] = useState(true);
  const [expandedApp, setExpandedApp] = useState<string | null>(null);

  useEffect(() => {
    const fetchApplications = async () => {
      if (!profile?.id) return;

      // First get student id
      const { data: studentData } = await supabase
        .from('students')
        .select('id')
        .eq('profile_id', profile.id)
        .single();

      if (!studentData) {
        setLoading(false);
        return;
      }

      const { data: appsData } = await supabase
        .from('applications')
        .select(`
          id,
          current_round,
          round_status,
          timeline,
          created_at,
          company:companies(company_name, job_role, package_lpa, rounds)
        `)
        .eq('student_id', studentData.id)
        .order('created_at', { ascending: false });

      if (appsData) {
        setApplications(appsData as unknown as Application[]);
      }

      setLoading(false);
    };

    fetchApplications();
  }, [profile?.id]);

  if (loading) {
    return (
      <DashboardLayout>
        <div className="space-y-6 animate-pulse">
          <div className="h-8 w-48 bg-muted rounded" />
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-32 bg-muted rounded-xl" />
            ))}
          </div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="page-header">
          <div>
            <h1 className="page-title">My Applications</h1>
            <p className="page-subtitle">Track your application status and progress</p>
          </div>
        </div>

        {/* Applications List */}
        {applications.length === 0 ? (
          <div className="empty-state py-16">
            <FileText className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-lg font-medium text-foreground">No applications yet</p>
            <p className="text-muted-foreground">Start applying to companies to see them here</p>
          </div>
        ) : (
          <div className="space-y-4">
            {applications.map((app) => {
              const status = statusConfig[app.round_status] || statusConfig.pending;
              const isExpanded = expandedApp === app.id;
              const rounds = app.company?.rounds || [];
              const totalRounds = rounds.length || 1;

              return (
                <Card key={app.id} className="dashboard-card overflow-hidden">
                  <CardHeader
                    className="pb-3 cursor-pointer"
                    onClick={() => setExpandedApp(isExpanded ? null : app.id)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                          <Building2 className="h-6 w-6 text-primary" />
                        </div>
                        <div>
                          <CardTitle className="text-lg">{app.company?.company_name}</CardTitle>
                          <p className="text-sm text-muted-foreground">{app.company?.job_role}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-right hidden sm:block">
                          <Badge className={status.className}>
                            {status.icon}
                            <span className="ml-1">{status.label}</span>
                          </Badge>
                          <p className="text-xs text-muted-foreground mt-1">
                            Round {app.current_round} of {totalRounds}
                          </p>
                        </div>
                        {isExpanded ? (
                          <ChevronUp className="h-5 w-5 text-muted-foreground" />
                        ) : (
                          <ChevronDown className="h-5 w-5 text-muted-foreground" />
                        )}
                      </div>
                    </div>
                  </CardHeader>

                  {isExpanded && (
                    <CardContent className="pt-0 border-t border-border">
                      <div className="pt-4 space-y-4">
                        {/* Package Info */}
                        <div className="flex items-center gap-4 text-sm">
                          <span className="text-muted-foreground">Package:</span>
                          <span className="font-medium text-foreground">{app.company?.package_lpa} LPA</span>
                          <span className="text-muted-foreground">Applied:</span>
                          <span className="font-medium text-foreground">
                            {format(new Date(app.created_at), 'MMM d, yyyy')}
                          </span>
                        </div>

                        {/* Timeline */}
                        <div className="relative">
                          <h4 className="text-sm font-medium text-foreground mb-3">Application Timeline</h4>
                          <div className="space-y-3">
                            {(app.timeline as TimelineEntry[] || []).map((entry, idx) => {
                              const entryStatus = statusConfig[entry.status] || statusConfig.pending;
                              return (
                                <div key={idx} className="flex items-start gap-3">
                                  <div className={cn(
                                    "w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0",
                                    entry.status === 'selected' && "bg-success/10 text-success",
                                    entry.status === 'rejected' && "bg-destructive/10 text-destructive",
                                    (entry.status === 'pending' || entry.status === 'applied' || entry.status === 'in_progress') && "bg-warning/10 text-warning"
                                  )}>
                                    {entryStatus.icon}
                                  </div>
                                  <div className="flex-1 min-w-0">
                                    <div className="flex items-center justify-between">
                                      <p className="text-sm font-medium text-foreground">
                                        Round {entry.round}: {entryStatus.label}
                                      </p>
                                      <span className="text-xs text-muted-foreground">
                                        {format(new Date(entry.timestamp), 'MMM d, h:mm a')}
                                      </span>
                                    </div>
                                    {entry.notes && (
                                      <p className="text-sm text-muted-foreground mt-1">{entry.notes}</p>
                                    )}
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        </div>

                        {/* Rounds Overview */}
                        {rounds.length > 0 && (
                          <div>
                            <h4 className="text-sm font-medium text-foreground mb-3">Selection Process</h4>
                            <div className="flex flex-wrap gap-2">
                              {rounds.map((round: any, idx: number) => (
                                <Badge
                                  key={idx}
                                  variant={idx + 1 <= app.current_round ? 'default' : 'outline'}
                                  className={cn(
                                    idx + 1 < app.current_round && "bg-success text-success-foreground",
                                    idx + 1 === app.current_round && "bg-primary text-primary-foreground"
                                  )}
                                >
                                  {idx + 1}. {round.name || round}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  )}
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
