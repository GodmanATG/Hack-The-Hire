import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import {
  Building2,
  FileText,
  CheckCircle2,
  Clock,
  AlertCircle,
  ChevronRight,
  Upload,
  User,
  Briefcase,
} from 'lucide-react';

interface StudentData {
  id: string;
  department: string;
  batch: string;
  cgpa: number | null;
  skills: string[];
  backlogs: boolean;
  resume_url: string | null;
  profile_status: string;
  profile_completion: number;
}

interface Company {
  id: string;
  company_name: string;
  job_role: string;
  package_lpa: number;
  application_deadline: string | null;
  status: string;
}

interface Application {
  id: string;
  current_round: number;
  round_status: string;
  created_at: string;
  company: {
    company_name: string;
    job_role: string;
  };
}

export default function StudentDashboard() {
  const { profile } = useAuth();
  const [student, setStudent] = useState<StudentData | null>(null);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [applications, setApplications] = useState<Application[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      if (!profile?.id) return;

      // Fetch student data
      const { data: studentData } = await supabase
        .from('students')
        .select('*')
        .eq('profile_id', profile.id)
        .single();

      if (studentData) {
        setStudent(studentData as StudentData);

        // Fetch applications
        const { data: appsData } = await supabase
          .from('applications')
          .select(`
            id,
            current_round,
            round_status,
            created_at,
            company:companies(company_name, job_role)
          `)
          .eq('student_id', studentData.id)
          .order('created_at', { ascending: false })
          .limit(5);

        if (appsData) {
          setApplications(appsData as unknown as Application[]);
        }
      }

      // Fetch open companies
      const { data: companiesData } = await supabase
        .from('companies')
        .select('id, company_name, job_role, package_lpa, application_deadline, status')
        .eq('status', 'open')
        .order('created_at', { ascending: false })
        .limit(5);

      if (companiesData) {
        setCompanies(companiesData);
      }

      setLoading(false);
    };

    fetchData();
  }, [profile?.id]);

  const profileCompletion = student?.profile_completion || 0;
  const hasResume = !!student?.resume_url;
  const isApproved = student?.profile_status === 'approved';

  const stats = [
    {
      label: 'Open Positions',
      value: companies.length,
      icon: <Briefcase className="h-5 w-5 text-primary" />,
      color: 'bg-primary/10',
    },
    {
      label: 'Applications',
      value: applications.length,
      icon: <FileText className="h-5 w-5 text-info" />,
      color: 'bg-info/10',
    },
    {
      label: 'Profile Status',
      value: isApproved ? 'Approved' : 'Pending',
      icon: isApproved ? (
        <CheckCircle2 className="h-5 w-5 text-success" />
      ) : (
        <Clock className="h-5 w-5 text-warning" />
      ),
      color: isApproved ? 'bg-success/10' : 'bg-warning/10',
    },
  ];

  if (loading) {
    return (
      <DashboardLayout>
        <div className="space-y-6 animate-pulse">
          <div className="h-8 w-48 bg-muted rounded" />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-24 bg-muted rounded-xl" />
            ))}
          </div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold text-foreground">
            Welcome back, {profile?.name?.split(' ')[0]}!
          </h1>
          <p className="text-muted-foreground">
            Here's an overview of your placement journey
          </p>
        </div>

        {/* Alerts */}
        {!student && (
          <Card className="border-warning bg-warning/5">
            <CardContent className="flex items-center gap-4 p-4">
              <AlertCircle className="h-5 w-5 text-warning flex-shrink-0" />
              <div className="flex-1">
                <p className="font-medium text-foreground">Complete Your Profile</p>
                <p className="text-sm text-muted-foreground">
                  You need to complete your student profile to apply for placements
                </p>
              </div>
              <Link to="/student/profile">
                <Button size="sm">Complete Profile</Button>
              </Link>
            </CardContent>
          </Card>
        )}

        {student && !hasResume && (
          <Card className="border-warning bg-warning/5">
            <CardContent className="flex items-center gap-4 p-4">
              <Upload className="h-5 w-5 text-warning flex-shrink-0" />
              <div className="flex-1">
                <p className="font-medium text-foreground">Upload Your Resume</p>
                <p className="text-sm text-muted-foreground">
                  A resume is required to apply for placements
                </p>
              </div>
              <Link to="/student/profile">
                <Button size="sm" variant="outline">Upload Resume</Button>
              </Link>
            </CardContent>
          </Card>
        )}

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {stats.map((stat) => (
            <Card key={stat.label} className="dashboard-card">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">{stat.label}</p>
                    <p className="text-2xl font-bold text-foreground mt-1">{stat.value}</p>
                  </div>
                  <div className={`p-3 rounded-xl ${stat.color}`}>
                    {stat.icon}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Profile Completion */}
        {student && (
          <Card className="dashboard-card">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">Profile Completion</CardTitle>
                <span className="text-2xl font-bold text-primary">{profileCompletion}%</span>
              </div>
            </CardHeader>
            <CardContent>
              <Progress value={profileCompletion} className="h-2" />
              <div className="flex items-center gap-4 mt-4 text-sm">
                <div className="flex items-center gap-2">
                  {student.cgpa ? (
                    <CheckCircle2 className="h-4 w-4 text-success" />
                  ) : (
                    <AlertCircle className="h-4 w-4 text-muted-foreground" />
                  )}
                  <span className={student.cgpa ? 'text-foreground' : 'text-muted-foreground'}>
                    CGPA
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  {hasResume ? (
                    <CheckCircle2 className="h-4 w-4 text-success" />
                  ) : (
                    <AlertCircle className="h-4 w-4 text-muted-foreground" />
                  )}
                  <span className={hasResume ? 'text-foreground' : 'text-muted-foreground'}>
                    Resume
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  {student.skills?.length > 0 ? (
                    <CheckCircle2 className="h-4 w-4 text-success" />
                  ) : (
                    <AlertCircle className="h-4 w-4 text-muted-foreground" />
                  )}
                  <span className={student.skills?.length > 0 ? 'text-foreground' : 'text-muted-foreground'}>
                    Skills
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Open Companies */}
          <Card className="dashboard-card">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Building2 className="h-5 w-5 text-primary" />
                  Open Positions
                </CardTitle>
                <Link to="/student/companies">
                  <Button variant="ghost" size="sm">
                    View All <ChevronRight className="ml-1 h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </CardHeader>
            <CardContent>
              {companies.length === 0 ? (
                <div className="empty-state py-8">
                  <Building2 className="h-10 w-10 text-muted-foreground mb-3" />
                  <p className="text-muted-foreground">No open positions yet</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {companies.map((company) => (
                    <div
                      key={company.id}
                      className="flex items-center justify-between p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
                    >
                      <div>
                        <p className="font-medium text-foreground">{company.company_name}</p>
                        <p className="text-sm text-muted-foreground">{company.job_role}</p>
                      </div>
                      <Badge variant="secondary">{company.package_lpa} LPA</Badge>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Recent Applications */}
          <Card className="dashboard-card">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg flex items-center gap-2">
                  <FileText className="h-5 w-5 text-info" />
                  Recent Applications
                </CardTitle>
                <Link to="/student/applications">
                  <Button variant="ghost" size="sm">
                    View All <ChevronRight className="ml-1 h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </CardHeader>
            <CardContent>
              {applications.length === 0 ? (
                <div className="empty-state py-8">
                  <FileText className="h-10 w-10 text-muted-foreground mb-3" />
                  <p className="text-muted-foreground">No applications yet</p>
                  <Link to="/student/companies" className="mt-3">
                    <Button size="sm" variant="outline">Browse Companies</Button>
                  </Link>
                </div>
              ) : (
                <div className="space-y-3">
                  {applications.map((app) => (
                    <div
                      key={app.id}
                      className="flex items-center justify-between p-3 rounded-lg bg-muted/50"
                    >
                      <div>
                        <p className="font-medium text-foreground">{app.company?.company_name}</p>
                        <p className="text-sm text-muted-foreground">{app.company?.job_role}</p>
                      </div>
                      <div className="text-right">
                        <Badge
                          variant="outline"
                          className={
                            app.round_status === 'selected'
                              ? 'status-approved'
                              : app.round_status === 'rejected'
                              ? 'status-rejected'
                              : 'status-pending'
                          }
                        >
                          {app.round_status}
                        </Badge>
                        <p className="text-xs text-muted-foreground mt-1">
                          Round {app.current_round}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
