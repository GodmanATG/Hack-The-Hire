import { useEffect, useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Users,
  Briefcase,
  CheckCircle2,
  Clock,
  XCircle,
  ChevronRight,
  Building2,
} from 'lucide-react';
import { Link } from 'react-router-dom';

interface Company {
  id: string;
  company_name: string;
  job_role: string;
  package_lpa: number;
  status: string;
}

interface ApplicationStats {
  total: number;
  pending: number;
  selected: number;
  rejected: number;
}

export default function CompanyDashboard() {
  const { profile } = useAuth();
  const [companies, setCompanies] = useState<Company[]>([]);
  const [stats, setStats] = useState<ApplicationStats>({ total: 0, pending: 0, selected: 0, rejected: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      if (!profile?.id) return;

      // Fetch companies by this HR
      const { data: companyData } = await supabase
        .from('companies')
        .select('*')
        .eq('profile_id', profile.id)
        .order('created_at', { ascending: false });

      if (companyData) {
        setCompanies(companyData);

        // Fetch application stats for these companies
        const companyIds = companyData.map(c => c.id);
        if (companyIds.length > 0) {
          const { data: appsData } = await supabase
            .from('applications')
            .select('round_status')
            .in('company_id', companyIds);

          if (appsData) {
            const total = appsData.length;
            const pending = appsData.filter(a => a.round_status === 'pending' || a.round_status === 'in_progress').length;
            const selected = appsData.filter(a => a.round_status === 'selected').length;
            const rejected = appsData.filter(a => a.round_status === 'rejected').length;
            setStats({ total, pending, selected, rejected });
          }
        }
      }

      setLoading(false);
    };

    fetchData();
  }, [profile?.id]);

  const statCards = [
    {
      label: 'Total Applicants',
      value: stats.total,
      icon: <Users className="h-5 w-5 text-primary" />,
      color: 'bg-primary/10',
    },
    {
      label: 'Pending Review',
      value: stats.pending,
      icon: <Clock className="h-5 w-5 text-warning" />,
      color: 'bg-warning/10',
    },
    {
      label: 'Selected',
      value: stats.selected,
      icon: <CheckCircle2 className="h-5 w-5 text-success" />,
      color: 'bg-success/10',
    },
    {
      label: 'Rejected',
      value: stats.rejected,
      icon: <XCircle className="h-5 w-5 text-destructive" />,
      color: 'bg-destructive/10',
    },
  ];

  if (loading) {
    return (
      <DashboardLayout>
        <div className="space-y-6 animate-pulse">
          <div className="h-8 w-48 bg-muted rounded" />
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="h-24 bg-muted rounded-xl" />
            ))}
          </div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">
              Welcome, {profile?.name?.split(' ')[0]}!
            </h1>
            <p className="text-muted-foreground">
              Manage your job postings and applicants
            </p>
          </div>
          <Link to="/company/jobs">
            <Button>
              <Briefcase className="mr-2 h-4 w-4" />
              Post New Job
            </Button>
          </Link>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {statCards.map((stat) => (
            <Card key={stat.label} className="dashboard-card">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">{stat.label}</p>
                    <p className="text-2xl font-bold text-foreground mt-1">{stat.value}</p>
                  </div>
                  <div className={`p-3 rounded-xl ${stat.color}`}>
                    {stat.icon}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Job Postings */}
        <Card className="dashboard-card">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg flex items-center gap-2">
                <Briefcase className="h-5 w-5 text-primary" />
                Your Job Postings
              </CardTitle>
              <Link to="/company/jobs">
                <Button variant="ghost" size="sm">
                  Manage <ChevronRight className="ml-1 h-4 w-4" />
                </Button>
              </Link>
            </div>
          </CardHeader>
          <CardContent>
            {companies.length === 0 ? (
              <div className="empty-state py-8">
                <Briefcase className="h-10 w-10 text-muted-foreground mb-3" />
                <p className="text-muted-foreground">No job postings yet</p>
                <Link to="/company/jobs" className="mt-3">
                  <Button size="sm">Post Your First Job</Button>
                </Link>
              </div>
            ) : (
              <div className="space-y-3">
                {companies.slice(0, 5).map((company) => (
                  <div
                    key={company.id}
                    className="flex items-center justify-between p-4 rounded-lg bg-muted/50"
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                        <Building2 className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium text-foreground">{company.company_name}</p>
                        <p className="text-sm text-muted-foreground">{company.job_role}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Badge variant="secondary">{company.package_lpa} LPA</Badge>
                      <Badge className={company.status === 'open' ? 'status-open' : 'status-closed'}>
                        {company.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
