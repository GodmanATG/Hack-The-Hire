import { useEffect, useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Briefcase,
  Plus,
  Trash2,
  Loader2,
  Building2,
  Save,
  X,
  Calendar,
  DollarSign,
} from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

interface Company {
  id: string;
  company_name: string;
  job_role: string;
  job_description: string | null;
  package_lpa: number;
  eligibility_criteria: any;
  application_deadline: string | null;
  rounds: any;
  status: string;
  created_at: string;
}


export default function CompanyJobs() {
  const { profile } = useAuth();
  const [companies, setCompanies] = useState<Company[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [saving, setSaving] = useState(false);

  // Form state
  const [companyName, setCompanyName] = useState('');
  const [jobRole, setJobRole] = useState('');
  const [jobDescription, setJobDescription] = useState('');
  const [packageLpa, setPackageLpa] = useState('');
  const [deadline, setDeadline] = useState('');
  const [minCgpa, setMinCgpa] = useState('');
  const [noBacklogs, setNoBacklogs] = useState(true);
  const [departments, setDepartments] = useState<string[]>([]);
  const [newDept, setNewDept] = useState('');
  const [requiredSkills, setRequiredSkills] = useState<string[]>([]);
  const [newSkill, setNewSkill] = useState('');
  const [rounds, setRounds] = useState<string[]>(['Resume Screening', 'Technical Interview', 'HR Interview']);
  const [newRound, setNewRound] = useState('');

  useEffect(() => {
    fetchCompanies();
  }, [profile?.id]);

  const fetchCompanies = async () => {
    if (!profile?.id) return;

    const { data } = await supabase
      .from('companies')
      .select('*')
      .eq('profile_id', profile.id)
      .order('created_at', { ascending: false });

    if (data) {
      setCompanies(data as Company[]);
    }
    setLoading(false);
  };

  const resetForm = () => {
    setCompanyName('');
    setJobRole('');
    setJobDescription('');
    setPackageLpa('');
    setDeadline('');
    setMinCgpa('');
    setNoBacklogs(true);
    setDepartments([]);
    setRequiredSkills([]);
    setRounds(['Resume Screening', 'Technical Interview', 'HR Interview']);
  };

  const handleSave = async () => {
    if (!companyName || !jobRole || !packageLpa) {
      toast.error('Please fill in required fields');
      return;
    }

    setSaving(true);

    const companyData = {
      profile_id: profile?.id,
      company_name: companyName,
      hr_name: profile?.name || 'HR',
      hr_email: profile?.email || '',
      job_role: jobRole,
      job_description: jobDescription || null,
      package_lpa: parseFloat(packageLpa),
      application_deadline: deadline || null,
      eligibility_criteria: {
        min_cgpa: minCgpa ? parseFloat(minCgpa) : undefined,
        departments: departments.length > 0 ? departments : undefined,
        skills: requiredSkills.length > 0 ? requiredSkills : undefined,
        no_backlogs: noBacklogs || undefined,
      },
      rounds: rounds.map(r => ({ name: r })),
      status: 'open' as const,
    };

    const { error } = await supabase.from('companies').insert(companyData);

    if (error) {
      toast.error('Failed to create job posting', { description: error.message });
    } else {
      toast.success('Job posting created!');
      setDialogOpen(false);
      resetForm();
      fetchCompanies();
    }

    setSaving(false);
  };

  const toggleStatus = async (company: Company) => {
    const newStatus = company.status === 'open' ? 'closed' : 'open';
    
    const { error } = await supabase
      .from('companies')
      .update({ status: newStatus })
      .eq('id', company.id);

    if (error) {
      toast.error('Failed to update status');
    } else {
      toast.success(`Job posting ${newStatus === 'open' ? 'opened' : 'closed'}`);
      fetchCompanies();
    }
  };

  if (loading) {
    return (
      <DashboardLayout>
        <div className="space-y-6 animate-pulse">
          <div className="h-8 w-48 bg-muted rounded" />
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-32 bg-muted rounded-xl" />
            ))}
          </div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="page-header">
          <div>
            <h1 className="page-title">Job Postings</h1>
            <p className="page-subtitle">Manage your company's job listings</p>
          </div>
          <Button onClick={() => setDialogOpen(true)}>
            <Plus className="mr-2 h-4 w-4" />
            New Posting
          </Button>
        </div>

        {/* Job Listings */}
        {companies.length === 0 ? (
          <div className="empty-state py-16">
            <Briefcase className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-lg font-medium text-foreground">No job postings yet</p>
            <p className="text-muted-foreground mb-4">Create your first job posting to start receiving applications</p>
            <Button onClick={() => setDialogOpen(true)}>
              <Plus className="mr-2 h-4 w-4" />
              Create First Posting
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {companies.map((company) => (
              <Card key={company.id} className="dashboard-card">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                        <Building2 className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-foreground">{company.company_name}</h3>
                        <p className="text-muted-foreground">{company.job_role}</p>
                        <div className="flex flex-wrap gap-4 mt-3 text-sm">
                          <div className="flex items-center gap-1.5">
                            <DollarSign className="h-4 w-4 text-muted-foreground" />
                            <span className="font-medium">{company.package_lpa} LPA</span>
                          </div>
                          {company.application_deadline && (
                            <div className="flex items-center gap-1.5">
                              <Calendar className="h-4 w-4 text-muted-foreground" />
                              <span>Deadline: {format(new Date(company.application_deadline), 'MMM d, yyyy')}</span>
                            </div>
                          )}
                        </div>
                        {/* Rounds */}
                        <div className="flex flex-wrap gap-2 mt-3">
                          {company.rounds?.map((round, idx) => (
                            <Badge key={idx} variant="outline">
                              {idx + 1}. {round.name}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Button
                        variant={company.status === 'open' ? 'outline' : 'default'}
                        size="sm"
                        onClick={() => toggleStatus(company)}
                      >
                        {company.status === 'open' ? 'Close' : 'Reopen'}
                      </Button>
                      <Badge className={company.status === 'open' ? 'status-open' : 'status-closed'}>
                        {company.status}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Create Job Dialog */}
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Create Job Posting</DialogTitle>
              <DialogDescription>
                Fill in the details to create a new job posting
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-6 py-4">
              {/* Basic Info */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="companyName">Company Name *</Label>
                  <Input
                    id="companyName"
                    value={companyName}
                    onChange={(e) => setCompanyName(e.target.value)}
                    placeholder="e.g., TechCorp India"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="jobRole">Job Role *</Label>
                  <Input
                    id="jobRole"
                    value={jobRole}
                    onChange={(e) => setJobRole(e.target.value)}
                    placeholder="e.g., Software Engineer"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Job Description</Label>
                <Textarea
                  id="description"
                  value={jobDescription}
                  onChange={(e) => setJobDescription(e.target.value)}
                  placeholder="Describe the role, responsibilities, and requirements..."
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="package">Package (LPA) *</Label>
                  <Input
                    id="package"
                    type="number"
                    step="0.5"
                    value={packageLpa}
                    onChange={(e) => setPackageLpa(e.target.value)}
                    placeholder="e.g., 8.5"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="deadline">Application Deadline</Label>
                  <Input
                    id="deadline"
                    type="date"
                    value={deadline}
                    onChange={(e) => setDeadline(e.target.value)}
                  />
                </div>
              </div>

              {/* Eligibility */}
              <Card className="bg-muted/50">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base">Eligibility Criteria</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="minCgpa">Minimum CGPA</Label>
                      <Input
                        id="minCgpa"
                        type="number"
                        step="0.1"
                        min="0"
                        max="10"
                        value={minCgpa}
                        onChange={(e) => setMinCgpa(e.target.value)}
                        placeholder="e.g., 7.0"
                      />
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-background">
                      <Label htmlFor="noBacklogs">No Backlogs Required</Label>
                      <Switch
                        id="noBacklogs"
                        checked={noBacklogs}
                        onCheckedChange={setNoBacklogs}
                      />
                    </div>
                  </div>

                  {/* Departments */}
                  <div className="space-y-2">
                    <Label>Eligible Departments</Label>
                    <div className="flex gap-2">
                      <Input
                        value={newDept}
                        onChange={(e) => setNewDept(e.target.value)}
                        placeholder="Add department"
                        onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), newDept && setDepartments([...departments, newDept]), setNewDept(''))}
                      />
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => {
                          if (newDept) {
                            setDepartments([...departments, newDept]);
                            setNewDept('');
                          }
                        }}
                      >
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {departments.map((dept) => (
                        <Badge key={dept} variant="secondary">
                          {dept}
                          <button onClick={() => setDepartments(departments.filter(d => d !== dept))} className="ml-1">
                            <X className="h-3 w-3" />
                          </button>
                        </Badge>
                      ))}
                      {departments.length === 0 && (
                        <span className="text-xs text-muted-foreground">All departments eligible</span>
                      )}
                    </div>
                  </div>

                  {/* Skills */}
                  <div className="space-y-2">
                    <Label>Required Skills</Label>
                    <div className="flex gap-2">
                      <Input
                        value={newSkill}
                        onChange={(e) => setNewSkill(e.target.value)}
                        placeholder="Add skill"
                        onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), newSkill && setRequiredSkills([...requiredSkills, newSkill]), setNewSkill(''))}
                      />
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => {
                          if (newSkill) {
                            setRequiredSkills([...requiredSkills, newSkill]);
                            setNewSkill('');
                          }
                        }}
                      >
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {requiredSkills.map((skill) => (
                        <Badge key={skill} variant="secondary">
                          {skill}
                          <button onClick={() => setRequiredSkills(requiredSkills.filter(s => s !== skill))} className="ml-1">
                            <X className="h-3 w-3" />
                          </button>
                        </Badge>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Rounds */}
              <Card className="bg-muted/50">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base">Selection Rounds</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex gap-2">
                    <Input
                      value={newRound}
                      onChange={(e) => setNewRound(e.target.value)}
                      placeholder="Add round (e.g., Coding Test)"
                      onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), newRound && setRounds([...rounds, newRound]), setNewRound(''))}
                    />
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => {
                        if (newRound) {
                          setRounds([...rounds, newRound]);
                          setNewRound('');
                        }
                      }}
                    >
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="space-y-2">
                    {rounds.map((round, idx) => (
                      <div key={idx} className="flex items-center justify-between p-2 rounded bg-background">
                        <span className="text-sm">
                          <span className="font-medium text-muted-foreground mr-2">{idx + 1}.</span>
                          {round}
                        </span>
                        <button
                          onClick={() => setRounds(rounds.filter((_, i) => i !== idx))}
                          className="text-muted-foreground hover:text-destructive"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleSave} disabled={saving}>
                {saving ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Creating...
                  </>
                ) : (
                  <>
                    <Save className="mr-2 h-4 w-4" />
                    Create Posting
                  </>
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}
