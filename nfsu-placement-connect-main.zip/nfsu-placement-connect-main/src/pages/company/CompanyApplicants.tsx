import { useEffect, useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Users,
  Search,
  Filter,
  User,
  Mail,
  Phone,
  GraduationCap,
  Loader2,
} from 'lucide-react';
import { toast } from 'sonner';

interface Applicant {
  id: string;
  current_round: number;
  round_status: string;
  created_at: string;
  student: {
    id: string;
    department: string;
    batch: string;
    cgpa: number | null;
    skills: string[];
    phone: string | null;
    profile: {
      name: string;
      email: string;
    };
  };
  company: {
    id: string;
    company_name: string;
    job_role: string;
    rounds: { name: string }[];
  };
}

const statusOptions = [
  { value: 'pending', label: 'Pending' },
  { value: 'in_progress', label: 'In Progress' },
  { value: 'selected', label: 'Selected' },
  { value: 'rejected', label: 'Rejected' },
];

export default function CompanyApplicants() {
  const { profile } = useAuth();
  const [applicants, setApplicants] = useState<Applicant[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  useEffect(() => {
    fetchApplicants();
  }, [profile?.id]);

  const fetchApplicants = async () => {
    if (!profile?.id) return;

    // First get companies by this HR
    const { data: companyData } = await supabase
      .from('companies')
      .select('id')
      .eq('profile_id', profile.id);

    if (!companyData || companyData.length === 0) {
      setLoading(false);
      return;
    }

    const companyIds = companyData.map(c => c.id);

    // Fetch applications for these companies
    const { data: appsData } = await supabase
      .from('applications')
      .select(`
        id,
        current_round,
        round_status,
        created_at,
        student:students(
          id,
          department,
          batch,
          cgpa,
          skills,
          phone,
          profile:profiles(name, email)
        ),
        company:companies(id, company_name, job_role, rounds)
      `)
      .in('company_id', companyIds)
      .order('created_at', { ascending: false });

    if (appsData) {
      setApplicants(appsData as unknown as Applicant[]);
    }

    setLoading(false);
  };

  const updateStatus = async (applicationId: string, newStatus: string, currentRound: number) => {
    const { error } = await supabase
      .from('applications')
      .update({ round_status: newStatus })
      .eq('id', applicationId);

    if (error) {
      toast.error('Failed to update status');
      return;
    }

    toast.success('Status updated');
    fetchApplicants();
  };

  const advanceRound = async (applicant: Applicant) => {
    const totalRounds = applicant.company?.rounds?.length || 1;
    const nextRound = applicant.current_round + 1;

    if (nextRound > totalRounds) {
      toast.info('Already at the final round');
      return;
    }

    const { error } = await supabase
      .from('applications')
      .update({
        current_round: nextRound,
        round_status: 'pending',
      })
      .eq('id', applicant.id);

    if (error) {
      toast.error('Failed to advance round');
    } else {
      toast.success(`Advanced to round ${nextRound}`);
      fetchApplicants();
    }
  };

  const filteredApplicants = applicants.filter(app => {
    const matchesSearch = 
      app.student?.profile?.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      app.student?.profile?.email?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      app.student?.department?.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || app.round_status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  if (loading) {
    return (
      <DashboardLayout>
        <div className="space-y-6 animate-pulse">
          <div className="h-8 w-48 bg-muted rounded" />
          <div className="h-96 bg-muted rounded-xl" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="page-header">
          <div>
            <h1 className="page-title">Applicants</h1>
            <p className="page-subtitle">View and manage applications</p>
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by name, email, or department..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-40">
              <Filter className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Filter status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              {statusOptions.map(opt => (
                <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Applicants Table */}
        {filteredApplicants.length === 0 ? (
          <div className="empty-state py-16">
            <Users className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-lg font-medium text-foreground">No applicants found</p>
            <p className="text-muted-foreground">
              {applicants.length === 0 
                ? "You haven't received any applications yet"
                : "Try adjusting your search or filters"}
            </p>
          </div>
        ) : (
          <Card className="dashboard-card overflow-hidden">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Applicant</TableHead>
                    <TableHead>Position</TableHead>
                    <TableHead>Department</TableHead>
                    <TableHead>CGPA</TableHead>
                    <TableHead>Round</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredApplicants.map((app) => {
                    const totalRounds = app.company?.rounds?.length || 1;
                    return (
                      <TableRow key={app.id}>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                              <User className="h-4 w-4 text-primary" />
                            </div>
                            <div>
                              <p className="font-medium text-foreground">{app.student?.profile?.name}</p>
                              <p className="text-xs text-muted-foreground">{app.student?.profile?.email}</p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <p className="font-medium">{app.company?.company_name}</p>
                          <p className="text-xs text-muted-foreground">{app.company?.job_role}</p>
                        </TableCell>
                        <TableCell>{app.student?.department}</TableCell>
                        <TableCell>
                          {app.student?.cgpa ? (
                            <span className="font-medium">{app.student.cgpa}</span>
                          ) : (
                            <span className="text-muted-foreground">N/A</span>
                          )}
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">
                            {app.current_round} / {totalRounds}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Select
                            value={app.round_status}
                            onValueChange={(val) => updateStatus(app.id, val, app.current_round)}
                          >
                            <SelectTrigger className="w-32 h-8">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {statusOptions.map(opt => (
                                <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </TableCell>
                        <TableCell>
                          {app.current_round < totalRounds && app.round_status !== 'rejected' && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => advanceRound(app)}
                            >
                              Next Round
                            </Button>
                          )}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}
