import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { signOut, getRoleDashboardPath } from '@/lib/auth';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  GraduationCap,
  Building2,
  Shield,
  LayoutDashboard,
  Users,
  Briefcase,
  FileText,
  BarChart3,
  Settings,
  LogOut,
  Menu,
  X,
  ChevronRight,
  User,
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface NavItem {
  label: string;
  href: string;
  icon: React.ReactNode;
}

interface DashboardLayoutProps {
  children: React.ReactNode;
}

const getNavItems = (role: string): NavItem[] => {
  switch (role) {
    case 'student':
      return [
        { label: 'Dashboard', href: '/student', icon: <LayoutDashboard className="h-5 w-5" /> },
        { label: 'Companies', href: '/student/companies', icon: <Building2 className="h-5 w-5" /> },
        { label: 'Applications', href: '/student/applications', icon: <FileText className="h-5 w-5" /> },
        { label: 'Profile', href: '/student/profile', icon: <User className="h-5 w-5" /> },
      ];
    case 'company':
      return [
        { label: 'Dashboard', href: '/company', icon: <LayoutDashboard className="h-5 w-5" /> },
        { label: 'Applicants', href: '/company/applicants', icon: <Users className="h-5 w-5" /> },
        { label: 'Job Postings', href: '/company/jobs', icon: <Briefcase className="h-5 w-5" /> },
      ];
    case 'admin':
      return [
        { label: 'Dashboard', href: '/admin', icon: <LayoutDashboard className="h-5 w-5" /> },
        { label: 'Students', href: '/admin/students', icon: <GraduationCap className="h-5 w-5" /> },
        { label: 'Companies', href: '/admin/companies', icon: <Building2 className="h-5 w-5" /> },
        { label: 'Applications', href: '/admin/applications', icon: <FileText className="h-5 w-5" /> },
        { label: 'Analytics', href: '/admin/analytics', icon: <BarChart3 className="h-5 w-5" /> },
      ];
    default:
      return [];
  }
};

const getRoleIcon = (role: string) => {
  switch (role) {
    case 'student':
      return <GraduationCap className="h-5 w-5" />;
    case 'company':
      return <Building2 className="h-5 w-5" />;
    case 'admin':
      return <Shield className="h-5 w-5" />;
    default:
      return <User className="h-5 w-5" />;
  }
};

const getRoleLabel = (role: string) => {
  switch (role) {
    case 'student':
      return 'Student';
    case 'company':
      return 'Company HR';
    case 'admin':
      return 'Admin';
    default:
      return 'User';
  }
};

export const DashboardLayout = ({ children }: DashboardLayoutProps) => {
  const { profile } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const navItems = getNavItems(profile?.role || '');

  const handleSignOut = async () => {
    await signOut();
    navigate('/auth');
  };

  const initials = profile?.name
    ? profile.name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2)
    : 'U';

  return (
    <div className="min-h-screen bg-background">
      {/* Mobile sidebar backdrop */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-foreground/20 backdrop-blur-sm z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          "fixed top-0 left-0 z-50 h-full w-64 bg-card border-r border-border transform transition-transform duration-200 ease-in-out lg:translate-x-0",
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="flex items-center justify-between h-16 px-6 border-b border-border">
            <Link to={getRoleDashboardPath(profile?.role || 'student')} className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg gradient-navy flex items-center justify-center">
                <GraduationCap className="h-5 w-5 text-primary-foreground" />
              </div>
              <span className="font-bold text-foreground">NFSU Placements</span>
            </Link>
            <button
              className="lg:hidden p-1 rounded hover:bg-accent"
              onClick={() => setSidebarOpen(false)}
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* Role Badge */}
          <div className="px-6 py-4 border-b border-border">
            <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-primary/10 text-primary">
              {getRoleIcon(profile?.role || '')}
              <span className="text-sm font-medium">{getRoleLabel(profile?.role || '')}</span>
            </div>
          </div>

          {/* Navigation */}
          <nav className="flex-1 px-4 py-4 space-y-1 overflow-y-auto scrollbar-thin">
            {navItems.map((item) => {
              const isActive = location.pathname === item.href;
              return (
                <Link
                  key={item.href}
                  to={item.href}
                  className={cn(
                    "nav-link",
                    isActive && "nav-link-active"
                  )}
                  onClick={() => setSidebarOpen(false)}
                >
                  {item.icon}
                  <span>{item.label}</span>
                  {isActive && <ChevronRight className="ml-auto h-4 w-4" />}
                </Link>
              );
            })}
          </nav>

          {/* User Menu */}
          <div className="p-4 border-t border-border">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex items-center gap-3 w-full p-2 rounded-lg hover:bg-accent transition-colors">
                  <Avatar className="h-9 w-9">
                    <AvatarFallback className="bg-primary/10 text-primary font-medium">
                      {initials}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 text-left">
                    <p className="text-sm font-medium text-foreground truncate">{profile?.name}</p>
                    <p className="text-xs text-muted-foreground truncate">{profile?.email}</p>
                  </div>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuItem onClick={() => navigate('/settings')}>
                  <Settings className="mr-2 h-4 w-4" />
                  Settings
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleSignOut} className="text-destructive">
                  <LogOut className="mr-2 h-4 w-4" />
                  Sign Out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <div className="lg:pl-64">
        {/* Top header */}
        <header className="sticky top-0 z-30 h-16 bg-card/80 backdrop-blur-sm border-b border-border">
          <div className="flex items-center justify-between h-full px-4 lg:px-8">
            <button
              className="lg:hidden p-2 rounded-lg hover:bg-accent"
              onClick={() => setSidebarOpen(true)}
            >
              <Menu className="h-5 w-5" />
            </button>

            <div className="flex-1 lg:hidden text-center">
              <span className="font-semibold text-foreground">NFSU Placements</span>
            </div>

            <div className="hidden lg:block" />

            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground hidden sm:inline">
                Welcome, {profile?.name?.split(' ')[0]}
              </span>
            </div>
          </div>
        </header>

        {/* Page content */}
        <main className="p-4 lg:p-8">
          {children}
        </main>
      </div>
    </div>
  );
};
