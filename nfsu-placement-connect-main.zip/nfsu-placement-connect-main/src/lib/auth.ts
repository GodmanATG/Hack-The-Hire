import { supabase } from "@/integrations/supabase/client";

export type UserRole = 'student' | 'company' | 'admin';
export type AdminRole = 'super_admin' | 'placement_officer' | 'dept_admin';

export interface UserProfile {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  admin_role?: AdminRole | null;
  avatar_url?: string | null;
  created_at: string;
  updated_at: string;
}

export const NFSU_DOMAIN = '@nfsu.ac.in';

export const validateNFSUEmail = (email: string): boolean => {
  return email.toLowerCase().endsWith(NFSU_DOMAIN);
};

export const signUp = async (
  email: string,
  password: string,
  name: string,
  role: UserRole = 'student'
) => {
  // Only validate domain for students
  if (role === 'student' && !validateNFSUEmail(email)) {
    return { error: { message: `Student signup requires an ${NFSU_DOMAIN} email address` } };
  }

  const redirectUrl = `${window.location.origin}/`;

  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      emailRedirectTo: redirectUrl,
      data: {
        name,
        role,
      },
    },
  });

  return { data, error };
};

export const signIn = async (email: string, password: string) => {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });

  return { data, error };
};

export const signOut = async () => {
  const { error } = await supabase.auth.signOut();
  return { error };
};

export const getProfile = async (userId: string): Promise<UserProfile | null> => {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .single();

  if (error) {
    console.error('Error fetching profile:', error);
    return null;
  }

  return data as UserProfile;
};

export const getCurrentUser = async () => {
  const { data: { user } } = await supabase.auth.getUser();
  return user;
};

export const getRoleDashboardPath = (role: UserRole): string => {
  switch (role) {
    case 'student':
      return '/student';
    case 'company':
      return '/company';
    case 'admin':
      return '/admin';
    default:
      return '/';
  }
};
