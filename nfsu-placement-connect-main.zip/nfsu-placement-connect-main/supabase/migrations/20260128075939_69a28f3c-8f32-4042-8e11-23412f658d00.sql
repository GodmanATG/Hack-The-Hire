-- Create enum types for roles and statuses
CREATE TYPE public.user_role AS ENUM ('student', 'company', 'admin');
CREATE TYPE public.admin_role AS ENUM ('super_admin', 'placement_officer', 'dept_admin');
CREATE TYPE public.profile_status AS ENUM ('pending', 'approved', 'rejected');
CREATE TYPE public.application_status AS ENUM ('applied', 'in_progress', 'selected', 'rejected');
CREATE TYPE public.company_status AS ENUM ('open', 'closed');

-- Profiles table (linked to auth.users)
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  name TEXT NOT NULL,
  role user_role NOT NULL DEFAULT 'student',
  admin_role admin_role,
  avatar_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Students table
CREATE TABLE public.students (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE UNIQUE,
  department TEXT NOT NULL,
  batch TEXT NOT NULL,
  roll_number TEXT,
  cgpa DECIMAL(3,2) CHECK (cgpa >= 0 AND cgpa <= 10),
  skills TEXT[] DEFAULT '{}',
  backlogs BOOLEAN DEFAULT false,
  resume_url TEXT,
  phone TEXT,
  linkedin_url TEXT,
  is_blacklisted BOOLEAN DEFAULT false,
  profile_status profile_status DEFAULT 'pending',
  profile_completion INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Companies table
CREATE TABLE public.companies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  company_name TEXT NOT NULL,
  company_logo_url TEXT,
  hr_name TEXT NOT NULL,
  hr_email TEXT NOT NULL,
  job_role TEXT NOT NULL,
  job_description TEXT,
  package_lpa DECIMAL(5,2) NOT NULL,
  eligibility_criteria JSONB DEFAULT '{}',
  application_deadline TIMESTAMPTZ,
  rounds JSONB DEFAULT '[]',
  status company_status DEFAULT 'open',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Applications table
CREATE TABLE public.applications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  company_id UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  current_round INTEGER DEFAULT 1,
  round_status TEXT DEFAULT 'pending',
  timeline JSONB DEFAULT '[]',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(student_id, company_id)
);

-- Admin logs table
CREATE TABLE public.admin_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  action TEXT NOT NULL,
  target_type TEXT,
  target_id UUID,
  details JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.students ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.companies ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_logs ENABLE ROW LEVEL SECURITY;

-- Helper function to get user role
CREATE OR REPLACE FUNCTION public.get_user_role(user_id UUID)
RETURNS user_role
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT role FROM public.profiles WHERE id = user_id
$$;

-- Helper function to check if user is admin
CREATE OR REPLACE FUNCTION public.is_admin(user_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE id = user_id AND role = 'admin'
  )
$$;

-- Profiles policies
CREATE POLICY "Users can view their own profile" ON public.profiles
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile" ON public.profiles
  FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Admins can view all profiles" ON public.profiles
  FOR SELECT USING (public.is_admin(auth.uid()));

CREATE POLICY "Users can insert their own profile" ON public.profiles
  FOR INSERT WITH CHECK (auth.uid() = id);

-- Students policies
CREATE POLICY "Students can view their own data" ON public.students
  FOR SELECT USING (profile_id = auth.uid());

CREATE POLICY "Students can update their own data" ON public.students
  FOR UPDATE USING (profile_id = auth.uid());

CREATE POLICY "Students can insert their own data" ON public.students
  FOR INSERT WITH CHECK (profile_id = auth.uid());

CREATE POLICY "Admins can view all students" ON public.students
  FOR SELECT USING (public.is_admin(auth.uid()));

CREATE POLICY "Admins can update all students" ON public.students
  FOR UPDATE USING (public.is_admin(auth.uid()));

CREATE POLICY "Companies can view non-blacklisted approved students" ON public.students
  FOR SELECT USING (
    public.get_user_role(auth.uid()) = 'company' 
    AND is_blacklisted = false 
    AND profile_status = 'approved'
  );

-- Companies policies
CREATE POLICY "Anyone authenticated can view open companies" ON public.companies
  FOR SELECT USING (auth.uid() IS NOT NULL);

CREATE POLICY "Company HRs can update their own company" ON public.companies
  FOR UPDATE USING (profile_id = auth.uid());

CREATE POLICY "Company HRs can insert companies" ON public.companies
  FOR INSERT WITH CHECK (profile_id = auth.uid() OR profile_id IS NULL);

CREATE POLICY "Admins can manage all companies" ON public.companies
  FOR ALL USING (public.is_admin(auth.uid()));

-- Applications policies
CREATE POLICY "Students can view their own applications" ON public.applications
  FOR SELECT USING (
    student_id IN (SELECT id FROM public.students WHERE profile_id = auth.uid())
  );

CREATE POLICY "Students can insert applications" ON public.applications
  FOR INSERT WITH CHECK (
    student_id IN (SELECT id FROM public.students WHERE profile_id = auth.uid())
  );

CREATE POLICY "Admins can view all applications" ON public.applications
  FOR SELECT USING (public.is_admin(auth.uid()));

CREATE POLICY "Admins can update all applications" ON public.applications
  FOR UPDATE USING (public.is_admin(auth.uid()));

CREATE POLICY "Companies can view applications for their companies" ON public.applications
  FOR SELECT USING (
    company_id IN (SELECT id FROM public.companies WHERE profile_id = auth.uid())
  );

CREATE POLICY "Companies can update applications for their companies" ON public.applications
  FOR UPDATE USING (
    company_id IN (SELECT id FROM public.companies WHERE profile_id = auth.uid())
  );

-- Admin logs policies
CREATE POLICY "Admins can view all logs" ON public.admin_logs
  FOR SELECT USING (public.is_admin(auth.uid()));

CREATE POLICY "Admins can insert logs" ON public.admin_logs
  FOR INSERT WITH CHECK (public.is_admin(auth.uid()));

-- Create function to handle profile creation on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, name, role)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'name', split_part(NEW.email, '@', 1)),
    COALESCE((NEW.raw_user_meta_data->>'role')::user_role, 'student')
  );
  RETURN NEW;
END;
$$;

-- Trigger to create profile on signup
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Add updated_at triggers
CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_students_updated_at
  BEFORE UPDATE ON public.students
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_companies_updated_at
  BEFORE UPDATE ON public.companies
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_applications_updated_at
  BEFORE UPDATE ON public.applications
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();